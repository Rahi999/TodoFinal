import React, { useState } from 'react';

const Counter = ()=> {
  return (
    <h1>Counter</h1>
  )
}
export default Counter