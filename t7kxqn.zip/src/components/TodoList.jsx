import React from 'react';

const TodoList = ({ children })=> {
  return (
    <ul>
     <ul>{children}</ul>aa
    </ul>
  )
}

export default TodoList